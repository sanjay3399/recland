# nmodes-hiring-manager
Hiring Manager Bot server
