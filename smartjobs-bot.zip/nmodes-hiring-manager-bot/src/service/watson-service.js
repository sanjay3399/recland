"use strict";

let ConversationV1 = require('watson-developer-cloud/conversation/v1');
let DiscoveryV1 = require('watson-developer-cloud/discovery/v1');
let schedule = require('node-schedule');

const WatsonService = function() {

    const CONVERSATION_INFO = {
        USERNAME: "f8d9d10b-f31d-4597-9577-69c262d91bc5",
        PASSWORD: "f1hhtTCBFO4A",

        WORKSPACE_ID: {
            HIRING_MANAGER: "55e2e9cd-f8b2-4deb-87d5-ebaa689a165f"
        },
    };

    const DISCOVERY_INFO = {
        URL: "https://gateway.watsonplatform.net/discovery/api",
        USERNAME: "",
        PASSWORD: "",

        SERVICES: {
        }
    };

    let conversation;
    let discovery;

    let message = (text, context) => {
        const payload = {
            workspace_id: CONVERSATION_INFO.WORKSPACE_ID.HIRING_MANAGER,
            input: {
                text: text
            },
            context: context
        };

        return new Promise((resolve, reject) =>
            conversation.message(payload, (err, res) => {
                if (err) reject(err);
                else resolve(res);
            })
        );
    };

    let query = (serviceInfo, query) => {

        const payload = {
            environment_id: serviceInfo.ENVIRONMENT_ID,
            collection_id: serviceInfo.COLLECTION_ID,
            query: query
        };

        return new Promise((resolve, reject) =>
            discovery.query(payload, (err, res) => {
                if (err) reject(err);
                else resolve(res);
            })
        );
    };

    let filter = (serviceInfo, filter) => {
        const payload = {
            environment_id: serviceInfo.ENVIRONMENT_ID,
            collection_id: serviceInfo.COLLECTION_ID,
            filter: filter
        };

        return new Promise((resolve, reject) =>
            discovery.query(payload, (err, res) => {
                if (err) reject(err);
                else resolve(res);
            })
        );
    };

    let init = () => {
        conversation = new ConversationV1({
            username: CONVERSATION_INFO.USERNAME,
            password: CONVERSATION_INFO.PASSWORD,
            version_date: ConversationV1.VERSION_DATE_2017_04_21
        });

/*        discovery = new DiscoveryV1({
            username: DISCOVERY_INFO.USERNAME,
            password: DISCOVERY_INFO.PASSWORD,
            version_date: DiscoveryV1.VERSION_DATE_2017_04_27
        });*/
    };

    init();

    return {
        conversation: {
            message: message
        },
        discovery: {
            query: query,
            filter: filter
        }
    }
};

module.exports = WatsonService;

