"use strict";
let mysql = require('mysql');

function ProfileService() {

    let conn;

    const init = () => {
        conn = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "",
            database: "default_schema"
        })
    };

    init();

    return {

    }
}

module.exports = ProfileService;