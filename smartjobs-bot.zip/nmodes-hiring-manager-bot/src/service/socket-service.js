"use strict";

let sockjs = require('sockjs');
let WatsonService = require('./watson-service');

const SocketService = function(httpServer) {

    const sockjs_options = {
        sockjs_url: "http://cdn.jsdelivr.net/sockjs/1.0.1/sockjs.min.js"
    };

    let watson;
    let socket;
    let context = {}; // user state

    let onConnection = (conn) => {

        conn.name = `${conn.remoteAddress}:${conn.remotePort}`;
        console.log(`User '${conn.name}' has connected.\n`);
        conn.write(JSON.stringify({
            type: "text",
            payload: [
                "Welcome! Nice to see you here.\n" +
                "I'm Job bot and I will help you to find your next job Let's start with basics.\n" +
                "You can let me search for jobs any time from the menu (in the left corner on the bottom)\n" +
                "or just by sending me a 'search' command."
            ]
        }));
        conn.on('data', (data) => onData(conn, data));
        // Handle disconnects.
        conn.on('close', () => onClose(conn));
    };

    let onData = (conn, data) => {
        console.log("onData", data);
        handleUserResponse(conn, JSON.parse(data));
    };

    let onClose = (conn) => {
        console.log(`User '${conn.name}' has disconnected.\n`);
    };

    let handleUserResponse = (conn, json) => {
        console.log(context.state);
        console.log(context.state === "upload_resume");
        switch (context.state) {
            case "upload_resume":
                if (json.type === "file") {
                    conn.write(JSON.stringify({
                        type: "text",
                        payload: ["Resume uploaded."]
                    }));
                    context.state = "";
                    context.has_profile = true;
                }
                else {
                    conn.write(JSON.stringify({
                        type: "text",
                        payload: ["Please upload your resume first."]
                    }));
                }
                return;
        }

        switch (json.type) {
            case "text":
                watson.conversation.message(json.payload, context)
                    .then(res => handleWatsonResponse(res, conn))
                    .catch(err => console.error(err));
                break;
            case "file":
                console.log("file");
                break;
            default:
                console.log("default");
                break;
        }
    };


    let handleWatsonResponse = (res, conn) => {

        console.log("From Watson Conversation", res);
        context = res.context;
        switch (res.context.state) {
            case "upload_resume":
                console.log("upload_resume", context.position + ", " + context.location);
                conn.write(JSON.stringify({
                    type: "upload_resume",
                    payload: res.output.text
                }));
                break;
            default:
                conn.write(JSON.stringify({
                    type: "text",
                    payload: res.output.text
                }));
                break;
        }
    };

    let hasProfile = () => true;
    let validateFile = () => true;

    let init = (httpServer) => {
        watson = WatsonService();
        socket = sockjs.createServer(sockjs_options);
        socket.on('connection', conn => onConnection(conn));
        socket.installHandlers(httpServer, {prefix: '/bot'});
    };

    init(httpServer);
};

module.exports = SocketService;