import * as React from 'react';
import {Comment} from 'semantic-ui-react'

export class Message extends React.Component {

    constructor(props) {
        super(props);
        this.element;
    }

    filterText = (text) => {
        return text.split("\n")
            .map((item, key) => <span key={key}>{item}<br/></span>);
    };

    componentDidMount() {

        this.element.scrollIntoView();
    };

    render() {
        return (
            <Comment>
                <Comment.Avatar src={`${this.props.message.imageUrl}`} />
                <Comment.Content>
                    <Comment.Author as='a'>{`${this.props.message.userName}`}</Comment.Author>
                    <Comment.Metadata>
                        <div ref={(element) => {this.element = element}}>
                            {`${this.props.message.time.toLocaleString()}`}
                        </div>
                    </Comment.Metadata>
                    <Comment.Text>{this.filterText(this.props.message.text)}</Comment.Text>
                </Comment.Content>
            </Comment>
        );
    }
}