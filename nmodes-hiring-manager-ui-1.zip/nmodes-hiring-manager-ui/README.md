# nmodes-hiring-manager
Hiring Manager User Interface
