import * as React from 'react';
import { Input, Button, Icon } from 'semantic-ui-react'

export class InputField extends React.Component {

    constructor(props) {
        super(props);
        this.fileInputElement;
        this.style = {
            width: "100%"
        };
    }

    keyPress = (ev) => {
        if (ev.key === 'Enter' && ev.target.value) {
            this.props.sendText(ev.target.value);
            ev.target.value = '';
        }
    };

    onClickUploadResume = (ev) => {
        this.fileInputElement.click();
    };

    onFileSelected = (ev) => {
        let file = this.fileInputElement.files[0];

        if (file.size / 1024 / 1024 > 5) {
            //error
            console.log("file size over 5mb");
        } else {
            let reader = new FileReader();
            reader.onload = this.onFileLoad;
            reader.readAsText(file);
        }
    };

    onFileLoad = (ev) => {
        this.props.sendFile(ev.target.result);
    };

    render() {
        return (
            <Input fluid type='text' placeholder='Ask anything' action>
                <input id="file-upload" type="file" hidden multiple="false"
                       ref={(element) => this.fileInputElement = element}
                       onChange={(ev) => this.onFileSelected(ev)}/>
                <input onKeyPress={(ev) => this.keyPress(ev)}></input>
                <Button animated='vertical' color='teal'
                        onClick={(ev) => this.onClickUploadResume(ev)}>
                    <Button.Content visible><Icon name='upload'/></Button.Content>
                    <Button.Content hidden>Upload</Button.Content>
                </Button>
            </Input>
        );
    }
}