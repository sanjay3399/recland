import * as React from 'react';
import {connect} from 'react-redux';
import {InputField} from './InputField';
import Conversation from './Conversation';
import {addMessage} from '../action/addMessage';
import SockJS from 'sockjs-client';
import {Grid} from 'semantic-ui-react';


class ChatApp extends React.Component {

    constructor(props) {
        super(props);
        this.socket = this.connectServer();
        this.containerStyle = {
            position: 'relative',
            height: '100%',
            top: '0px'
        };
        this.wrapperStyle = {
            position: 'relative',
            top: '0px',
            height: 'calc(100% - 40px)'
        };
        this.conversationStyle = {
            position: 'absolute',
            maxHeight: 'calc(100% - 10px)', // for scroll bar
            width: '100%',
            bottom: '0px',     // to start at the bottom
            overflowY: 'auto',
        };
        this.inputFieldStyle = {
            position: 'absolute',
            bottom: '0px',
            width: '100%'
        };
    }

    connectServer = () => {
        let socket = new SockJS("http://" + window.location.hostname + ":3000/bot");
        socket.onopen = (ev) => this.onOpen(ev);
        socket.onmessage = (ev) => this.onMessage(ev);
        socket.onclose = (ev) => this.onClose(ev);
        socket.onerror = (ev) => this.onError(ev);
        return socket;
    };

    onOpen = (ev) => {
        console.log(`Connected the server at ${new Date()}`);
    };

    onClose = (ev) => {
        console.log(`Disconnected at ${new Date()}`);
    };

    // Message from the server
    onMessage = (ev) => {
        if (!ev.data)
            return;

        let json = JSON.parse(ev.data);

        json.payload.forEach(text => {
            this.props.dispatchMessage({
                userName: "Bot",
                text: text,
                imageUrl: "./image/bot.png",
                time: new Date()
            })
        });

        switch (json.type) {
            case "upload_resume":
                // do event
                break;
            default:
                break;
        }
    };

    onError = (ev) => {
        console.log("Error", ev);
    };

    sendText = (text)  => {
        if (this.socket) {
            this.socket.send(JSON.stringify({
                type: "text",
                payload: text
            }));

            this.props.dispatchMessage({
                userName: "Me",
                text: text,
                imageUrl: "./image/me.jpg",
                time: new Date()
            })
        }
    };

    sendFile = (file) => {
        if (this.socket) {
            this.socket.send(JSON.stringify({
                type: "file",
                payload: file
            }))
        }


    };

    render() {
        return (
            <Grid container style={this.containerStyle}>
                <Grid.Row style={this.wrapperStyle}><Grid.Column>
                    <Grid.Row style={this.conversationStyle}>
                        <Grid.Column><Conversation /></Grid.Column>
                    </Grid.Row>
                </Grid.Column></Grid.Row>
                <Grid.Row style={this.inputFieldStyle}>
                    <Grid.Column><InputField sendText={this.sendText} sendFile={this.sendFile}/></Grid.Column>
                </Grid.Row>
            </Grid>
        )
    }
}


// Receives dispatch() function and returns callback props
// that you want to inject into the presentational component
const mapDispatchToProps = (dispatch) => {
    return {
        dispatchMessage: (message) => dispatch(addMessage(message))
    }
};

export default connect(null, mapDispatchToProps)(ChatApp);