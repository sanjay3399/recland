import * as React from 'react';
import {connect} from 'react-redux';
import {Message} from './Message';
import {Comment} from 'semantic-ui-react';

class Conversation extends React.Component {

    constructor(props) {
        super(props);
        this.style = {};
    }

    render() {
        return (
            <Comment.Group>
                {
                    this.props.messages.map((message, key) =>
                        <Message key={key} message={message} />)
                }
            </Comment.Group>
        )
    }
}

Conversation.defaultProps = {
    messages: []
};


// Describe How to transform the current state into the props
const mapStateToProps = (state, ownProps) => {
    if (state.messages) {
        return {
            messages: state.messages.map(obj => obj.message)
        };
    }
};

export default connect(mapStateToProps, null)(Conversation)