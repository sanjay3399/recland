/**
 * Actions are payloads of information that send data from the app to the store
 * Only source of information for the store
 */
export const ADD_MESSAGE = "ADD_MESSAGE";
export const UPLOAD_FILE_SUCCESS = 'UPLOAD_FILE_SUCCESS';
export const UPLOAD_FILE_FAIL = 'UPLOAD_FILE_FAIL';
