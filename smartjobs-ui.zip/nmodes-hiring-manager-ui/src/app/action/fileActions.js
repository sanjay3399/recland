import {UPLOAD_FILE_FAIL, UPLOAD_FILE_SUCCESS} from "./ActionType";

export function uploadFileSuccess(data) {
    return {
        type: UPLOAD_FILE_SUCCESS,
        data,
    };
}

export function uploadFileFail(error) {
    return {
        type: UPLOAD_FILE_FAIL,
        error,
    };
}